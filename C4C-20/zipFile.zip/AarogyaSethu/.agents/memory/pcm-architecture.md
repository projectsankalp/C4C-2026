---
name: Passive Clinical Memory (PCM) Architecture
description: Longitudinal analysis engine location, API shape, and key design decisions.
---

# Passive Clinical Memory — Architecture

The PCM layer lives in `services/longitudinal_engine.py` and is exposed via `routes/longitudinal_routes.py`.

## Public API
- `build_longitudinal_summary(patient_id)` — full analysis (BP trend, risk trajectory, adherence, deviations, pathways, alerts, narrative)
- `build_snapshot(patient_id)` — lightweight version for embedding in list views

## REST Endpoints
- `GET /api/patients/<id>/longitudinal` — full PCM summary
- `GET /api/patients/<id>/snapshot` — lightweight snapshot
- `GET /api/risk/longitudinal-queue` — risk queue annotated with longitudinal data
- `GET /api/visits/<id>` — now includes `longitudinal_snapshot` + `risk_summary`

## Key Decisions
- **No ML**: all analysis is deterministic (statistics.mean, statistics.stdev, threshold comparisons)
- **Baseline definition**: first 1/3 of visits (min 2) vs last 1/3 of visits (min 2)
- **BP trend thresholds**: Δ ≥ 10 mmHg = WORSENING/IMPROVING; std ≥ 15 mmHg = VOLATILE
- **Risk trajectory thresholds**: Δ ≥ 15 = ESCALATING/IMPROVING
- **Adherence trend**: last 3 vs prior 3 missed-rate delta ≥ 0.25 = WORSENING
- **First-deviation types**: FIRST_ABNORMAL_BP, FIRST_HYPERTENSIVE_CRISIS, FIRST_CHEST_PAIN, FIRST_DIZZINESS, FIRST_MEDICATION_MISS, FIRST_CRISIS_ESCALATION, FIRST_TACHYCARDIA

## GCPE Integration
- `gcpe_data.pathways` consumed by `analyze_pathway_history()`
- `gcpe_data.answers.missed_reason` consumed by `analyze_adherence_trajectory()` and `detect_first_deviations()`
- Backward-compatible: visits without gcpe_data still produce valid longitudinal analysis

**Why:** Isolated visit storage behaves like a filing cabinet; the PCM layer makes it a healthcare memory system.
